-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2022 at 09:02 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `real_estate`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(1, 'ChiefAgibu', 'chiefagibu@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `image1` text NOT NULL,
  `image2` text NOT NULL,
  `image3` text NOT NULL,
  `image4` text NOT NULL,
  `property_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `image1`, `image2`, `image3`, `image4`, `property_id`) VALUES
(13, 'cora14.jpg', 'h5.jpg', 'ch.jpg', 'home3.jpg', 3),
(14, 'img1.jpg', 'img2.jpg', 'img3.jpg', 'hr14.jpg', 2),
(15, 'banner3.jpg', 'ch1.jpg', 'banner2.jpg', 'ban2.jpg', 4),
(16, 'hr10.jpg', 'cora9.jpg', 'banner1.jpg', 'cora6.jpg', 5);

-- --------------------------------------------------------

--
-- Table structure for table `inquiry`
--

CREATE TABLE `inquiry` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `email` text NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `message` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inquiry`
--

INSERT INTO `inquiry` (`id`, `name`, `subject`, `email`, `mobile`, `message`, `date`) VALUES
(1, 'Francis Agibu Kargbo', 'Thank', 'agent@gmail.com', '+232111111', 'This website is very useful and has helped me a lot. Thank you so much', '2022-06-01 23:29:15'),
(2, 'Osman Sesay', 'Alhaji', 'sesay@gmail.com', '+232114455', 'Thank you Guys', '2022-06-30 23:29:48'),
(3, 'Adama Kargbo', 'Alhaji', 'kargbo@gmail.com', '+232114455', 'Thank God', '2021-11-08 23:30:33'),
(4, 'Beatrice Winstonia', 'Beatrice', 'winstinia@gmail.com', '+232114455', 'Well done Guys', '2022-06-06 23:31:33'),
(5, '', '', '', '', '', '0000-00-00 00:00:00'),
(6, '', '', '', '', '', '0000-00-00 00:00:00'),
(7, '', '', '', '', '', '0000-00-00 00:00:00'),
(8, '', '', '', '', '', '0000-00-00 00:00:00'),
(9, 'Winston Solomon Karg', 'Solomon', 'solomon@gmail.com', '+23288112933', 'I love this website. It makes my life easy and comfortable Thanks to the dev. team', '0000-00-00 00:00:00'),
(10, 'Winston Solomon Karg', 'Solomon', 'solomon@gmail.com', '+23288112933', 'I love this website. It makes my life easy and comfortable Thanks to the dev. team', '0000-00-00 00:00:00'),
(11, 'Winston Solomon Karg', 'Solomon', 'solomon@gmail.com', '+23288112933', 'I love this website. It makes my life easy and comfortable Thanks to the dev. team', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `property`
--

CREATE TABLE `property` (
  `id` int(11) NOT NULL,
  `title` varchar(20) NOT NULL,
  `bedroom` int(11) NOT NULL,
  `hall` int(11) NOT NULL,
  `kichan` int(11) NOT NULL,
  `bathroom` int(11) NOT NULL,
  `balcony` int(11) NOT NULL,
  `price` varchar(11) NOT NULL,
  `sqr_price` varchar(11) NOT NULL,
  `address` text NOT NULL,
  `video` text NOT NULL,
  `image` text NOT NULL,
  `description` varchar(300) NOT NULL,
  `location` text NOT NULL,
  `property_owner` varchar(20) NOT NULL,
  `property_type` varchar(50) NOT NULL,
  `lot_size` varchar(20) NOT NULL,
  `sold` varchar(12) NOT NULL,
  `land_area` varchar(20) NOT NULL,
  `date` datetime NOT NULL,
  `property_desc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `property`
--

INSERT INTO `property` (`id`, `title`, `bedroom`, `hall`, `kichan`, `bathroom`, `balcony`, `price`, `sqr_price`, `address`, `video`, `image`, `description`, `location`, `property_owner`, `property_type`, `lot_size`, `sold`, `land_area`, `date`, `property_desc`) VALUES
(2, 'Self Contain', 1, 1, 1, 1, 1, '2000', '200', '13 Bo Rd, Magburaka', 'https://www.youtube.com/embed/rOO3MjLABi8', 'cora5.jpg', 'Did you play off any hot home styles this year to improve your listing appearance? These were some of the top home design fads.', 'Sierra Leone', 'Francis Kargbo', 'house', '200', 'yes', '200', '2019-01-12 12:10:13', 'For Sell'),
(3, '3 Rooms and palor', 1, 2, 1, 1, 1, '3000', '66', '66 Wilkinson Rd, Freetown', 'https://www.youtube.com/watch?v=ouLA38ZZHGY', 'cora7.jpg', 'Single Room and palor self contain', 'sierraleone', 'ChiefAgibu', 'Room and Palor Self Contain', '2ft', 'No', '126cm', '2022-06-15 01:38:18', 'For Rent'),
(4, 'Flat Land', 0, 0, 0, 0, 0, '1200', '2300', '22 Bo rd, Magburaka', 'https://www.youtube.com/watch?v=ouLA38ZZHGY', 'banner3.jpg', 'Flat land for sale', 'Sierra Leone', 'Winston', 'Land', '450', 'yes', '1000', '0000-00-00 00:00:00', 'For Sell'),
(5, 'A 3 flat Store', 3, 3, 3, 3, 3, '50000', '150', '60 Kissy Rd, Freetown, Sierra Leone.', 'https://www.youtube.com/watch?v=ouLA38ZZHGY', 'hr10.jpg', 'A 3 flat Store (Shops) for rent at No. 60 Kissy Rd, Freetown, Sierra Leone.', 'Kissy Rd, Freetown', 'Alhassan', 'Store', '100', 'no', '200', '0000-00-00 00:00:00', '2022-06-21 14:31:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inquiry`
--
ALTER TABLE `inquiry`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `property`
--
ALTER TABLE `property`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `inquiry`
--
ALTER TABLE `inquiry`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `property`
--
ALTER TABLE `property`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
