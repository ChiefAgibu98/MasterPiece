     <style>
		i{
			color:indigo;
		}
		
	 </style>

     <?php
     session_start();
$email=$_SESSION['email'];
$query=mysqli_query($con,"select * from admin where email='$email'");
$res1=mysqli_fetch_array($query);
@$name=$res1['name'];
     ?>

		<aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                    <img src="images/user.png" width="48" height="48" alt="User" />
                </div>
               
            </div>
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="header">MAIN NAVIGATION</li>

                    <li>
                        <a href="add_property.php" class="menu-toggle">
                            <span>Add Property</span>
                        </a>
                    </li>

                     <li>
                        <a href="view_property_image.php" class="menu-toggle">
                            <span>Add Property Images</span>
                        </a>
                    </li>


                    <li>
                        <a href="view_property.php" class="menu-toggle">
                            <span>View Property</span>
                        </a>
                    </li>
									                    
                    
                    
                    
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <span>Logout</span>
                        </a>
                        <ul class="ml-menu">
                          
                            <li>
                                <a href="logout.php">Sign Out</a>
                            </li>
                           
                        </ul>
                    </li>
             
                </ul>
            </div>
            <!-- #Menu -->
        
        </aside>