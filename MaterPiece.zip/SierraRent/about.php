<?php include('include/header.php');?>

<!-- Sub banner start -->
<div class="sub-banner overview-bgi">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>About Us</h1>
            <ul class="breadcrumbs">
                <li><a href="index.html">Home</a></li>
                <li class="active">About Us</li>
            </ul>
        </div>
    </div>
</div>
<!-- Sub banner end -->

<!-- About us start -->
<div class="about-us content-area-8 bg-white">
    <div class="container">
        <div class="row">
            <div class="col-lg-5">
                <div class="properties-service-v">
                    <img src="assets/img/imgs/ch.jpg" alt="admin" class="img-fluid">
                </div>
            </div>
            <div class="col-lg-7 align-self-center">
                <div class="about-text more-info">
                    <h3>Why Choose Us?</h3>
                    <div id="faq" class="faq-accordion">
                        <div class="card m-b-0">
                            <div class="card-header">
                                <a class="card-title collapsed" data-toggle="collapse" data-parent="#faq" href="#collapse1">
                                    Mission
                                </a>
                            </div>
                            <div id="collapse1" class="card-block collapse">
                                <p>Delivering the dream of home ownership everywhere.
                                    The <b>SierraRent</b> and infrstructure project have this same goal, because owning real estate provides security, safety and opportunity for individuals. The technology we build helps real estate agents become  more efficient at their job and find more customers to deliver on that mission. Our training prepares agents to be even better by utilizing exceptional techniques and systems, and the <b>SierraRent</b> Teams constantly help families find and sell homes.</p>
                            </div>

                            <div class="card-header">
                                <a class="card-title collapsed" data-toggle="collapse" data-parent="#faq" href="#collapse2">
                                    Vission
                                </a>
                            </div>
                            <div id="collapse2" class="card-block collapse">
                                <p>Win, Make, Give, and Do Good.

                                We want to win at what we do, and we do all we can to help our customers, agents and employees build wealth. We love to work with people who are passionate about working hard and also giving back to their communities in a big way.</p>
                            </div>

                            <div class="card-header">
                                <a class="card-title collapsed" data-toggle="collapse" data-parent="#faq" href="#collapse3">
                                    Honesty and integrity
                                </a>
                            </div>
                            <div id="collapse3" class="card-block collapse">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum et vel eros. Maecenas eros enim, tincidunt vel turpis vel, dapibus tempus nulla. Donec vel nulla dui. Pellentesque sed ante sed ligula hendrerit condimentum. Suspendisse rhoncus fringilla ipsum.</p>
                            </div>

                            <div class="card-header bd-none">
                                <a class="card-title collapsed" data-toggle="collapse" data-parent="#faq" href="#collapse4">
                                    Fast And Reliable
                                </a>
                            </div>
                            <div id="collapse4" class="card-block collapse">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus tincidunt aliquam. Aliquam gravida massa at sem vulputate interdum et vel eros. Maecenas eros enim, tincidunt vel turpis vel, dapibus tempus nulla. Donec vel nulla dui. Pellentesque sed ante sed ligula hendrerit condimentum. Suspendisse rhoncus fringilla ipsum.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About us end -->

<!-- agent start -->
<div class="agent content-area-2">
    <div class="container">
        <div class="main-title">
            <h1>Our Team</h1>
            <p>These people are responsible for the success of this project.</p>
        </div>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="agent-2">
                    <div class="agent-photo">
                        <a href="https://www.facebook.com/franc.kay.10">
                            <img src="assets/img/pics/chief.jpg" alt="avatar-5" class="img-fluid">
                        </a>
                    </div>
                    <div class="agent-details">
                        <h5><a href="https://www.linkedin.com/search/results/all/?keywords=francis%20agibu%20kargbo&origin=RICH_QUERY_SUGGESTION&position=0&searchId=0d539af7-c710-4779-8987-83daf9639b64&sid=_a">Francis Agibu Kargbo</a></h5>
                        <p>Full Stack Developer</p>
                        <ul class="social-list clearfix">
                            <li><a href="https://www.facebook.com/franc.kay.10" class="facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/AgibuKargbo" class="twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/franc.kay.10/" class="instagram"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com/search/results/all/?keywords=francis%20agibu%20kargbo&origin=RICH_QUERY_SUGGESTION&position=0&searchId=0d539af7-c710-4779-8987-83daf9639b64&sid=_a" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="agent-2">
                    <div class="agent-photo">
                        <a href="https://www.linkedin.com/in/mohamed-cf-woobay-4bb158175/">
                            <img src="assets/img/pics/woobay.jpeg" alt="avatar-6" class="img-fluid">
                        </a>
                    </div>
                    <div class="agent-details">
                        <h5><a href="https://www.facebook.com/mohamedcf.woobay"> Mohamed C.F. Woobay</a></h5>
                        <p>Backend Developer</p>
                        <ul class="social-list clearfix">
                            <li><a href="https://www.facebook.com/mohamedcf.woobay" class="facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/FuadWoobay" class="twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/cfwoobay/" class="instagram"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.linkedin.com/in/mohamed-cf-woobay-4bb158175/" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="agent-2">
                    <div class="agent-photo">
                        <a href="https://www.linkedin.com/in/mohamed-sanunu-barrie-90b351235/">
                            <img src="assets/img/pics/sanunu.jpeg" alt="avatar-7" class="img-fluid">
                        </a>
                    </div>
                    <div class="agent-details">
                        <h5><a href="https://m.facebook.com/100006650163974/">Sanunu Barrie</a></h5>
                        <p>Frontend UI/UX Designer</p>
                        <ul class="social-list clearfix">
                            <li><a href="https://m.facebook.com/100006650163974/" class="facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/SanunuBarrie" class="twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.linkedin.com/in/mohamed-sanunu-barrie-90b351235/" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                <div class="agent-2">
                    <div class="agent-photo">
                        <a href="http://www.linkedin.com/in/mohamed-fadil-bah-25218a1ab">
                            <img src="assets/img/pics/fadil.jpeg" alt="avatar-11" class="img-fluid">
                        </a>
                    </div>
                    <div class="agent-details">
                        <h5><a href="https://www.facebook.com/fadilbah9">Fadil Bah</a></h5>
                        <p>Project Manager</p>
                        <ul class="social-list clearfix">
                            <li><a href="https://www.facebook.com/fadilbah9" class="facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://fadilbah.netlify.app/" class="instagram"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="http://www.linkedin.com/in/mohamed-fadil-bah-25218a1ab" class="linkedin"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div >
<!-- agent end -->

<!-- Counters start -->
<div class="counters overview-bgi" style="background-image: url(assets/img/imgs/ban2.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-tag"></i>
                    <h1 class="counter">150</h1>
                    <h5>Lines of Sale</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-badge"></i>
                    <h1 class="counter">254</h1>
                    <h5>Listings For Rent</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-call-center-agent"></i>
                    <h1 class="counter">50</h1>
                    <h5>Agents</h5>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6">
                <div class="counter-box">
                    <i class="flaticon-job"></i>
                    <h1 class="counter">24</h1>
                    <h5>Brokers</h5>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Counters end -->

<!-- Testimonial 3 start -->
<div class="testimonial testimonial-3">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="testimonial-inner">
                    <header class="testimonia-header">
                        <h1>Testimonial</h1>
                    </header>
                    <div id="carouselExampleIndicators2" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carouselExampleIndicators2" data-slide-to="0" class="active"></li>
                            <li data-target="#carouselExampleIndicators2" data-slide-to="1"></li>
                            <li data-target="#carouselExampleIndicators2" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <p class="lead">
                                    I'm Grateful to your effort by creating this platform. It has eased the stress of acquiring and apartment. 
                                </p>
                                <div class="avatar">
                                    <img src="assets/img/pics/hamira.jpg" alt="avatar-2" class="img-fluid rounded">
                                </div>
                                <ul class="rating">
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star-half-full"></i>
                                    </li>
                                </ul>
                                <div class="author-name">
                                    Hamira V. Sesay
                                </div>
                            </div>
                            <div class="carousel-item">
                                <p class="lead">
                                    I've just bought a house with the help of this website.. Thank You so much, You are the best!!!!
                                </p>
                                <div class="avatar">
                                    <img src="assets/img/pics/pic1.jpg" alt="avatar" class="img-fluid rounded">
                                </div>
                                <ul class="rating">
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star-half-full"></i>
                                    </li>
                                </ul>
                                <div class="author-name">
                                   Chief Agibu
                                </div>
                            </div>
                            <div class="carousel-item">
                                <p class="lead">
                                    This site is Awesome and Super Good. Thanks your so much
                                </p>
                                <div class="avatar">
                                    <img src="assets/img/pics/sanunu.jpeg" alt="avatar-3" class="img-fluid rounded">
                                </div>
                                <ul class="rating">
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star"></i>
                                    </li>
                                    <li>
                                        <i class="fa fa-star-half-full"></i>
                                    </li>
                                </ul>
                                <div class="author-name">
                                        Sanunu Barrie
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial 3 end -->

<!-- Footer start -->
<?php include('include/footer.php');?>